<?php
/*
Template Name: Home
*/

get_header();
?>
<main>
<?php 
	get_template_part( SECTION . 'section-notfound');
?>
</main>

<?php
get_footer();
?>