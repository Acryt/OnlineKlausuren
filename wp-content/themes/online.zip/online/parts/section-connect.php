<section>
	<div class="wrapper">
		<?php
		get_template_part(SECTION . 'part-connect');
		?>
	</div>
</section>