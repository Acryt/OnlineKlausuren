<?php if (carbon_get_theme_option("cf_warning")) { ?>
	<section class="warning">
		<div class="wrapper upc">
			<p><strong><?php echo carbon_get_theme_option("cf_warning"); ?></strong></p>
		</div>
	</section>
<?php } ?>