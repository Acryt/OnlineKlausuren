<section class="content">
	<div class="wrapper">
		<?php the_content(); ?>
	</div>
</section>