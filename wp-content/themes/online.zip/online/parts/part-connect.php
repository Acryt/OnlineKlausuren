<div class="connect">
	<h4 class="upc">Die Kundenberaterin ist online. Stellen Sie ihr Ihre Fragen</h4>
	<p class="center">Wenn Sie innerhalb von 15 Minuten keine Antwort bekommen haben, prüfen Sie Ihre E-Mail oder
		Spam-Ordner.</p>
	<div class="connect__btns">
		<a class="btn__hover">
			<div class="connect__img"><img src="<?php echo URI . IMG . 'erica.jpg' ?>" alt=""></div>
			<i class="icon-whatsapp-w"></i>Erika
		</a>
		<a class="btn__hover"><i class="icon-email"></i>E-Mail schreiben</a>
		<a class="btn__hover"><i class="icon-phone"></i>Rückruf bestellen</a>
	</div>
</div>